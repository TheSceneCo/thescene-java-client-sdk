package nz.co.thescene.client.auth.grants;

public abstract class Grant {

	public abstract String getUri();

}
